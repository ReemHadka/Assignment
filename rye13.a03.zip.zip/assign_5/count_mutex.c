#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/time.h>

#define ARRAY_SIZE 10 
#define NUM_THREADS 2         

int *array;
int length = ARRAY_SIZE;
int count = 0;

pthread_mutex_t count_mutex;

void *count1s(void *thread_id) {
    long tid = (long)thread_id;
    int local_count = 0;

    for (int i = tid; i < length; i += NUM_THREADS) {
        if (array[i] == 1) {
            local_count++;
        }
    }

    
    pthread_mutex_lock(&count_mutex);
    count += local_count;
    pthread_mutex_unlock(&count_mutex);

    pthread_exit(NULL);
}

int main() {
    array = (int *)malloc(length * sizeof(int));
    srand((unsigned int)time(NULL));


    for (int i = 0; i < length; i++) {
        array[i] = rand() % 6;
    }


    pthread_mutex_init(&count_mutex, NULL);

    
    pthread_t threads[NUM_THREADS];
    int rc;
    long t;

    struct timeval start, end;

    gettimeofday(&start, NULL);

    // Create threads
    for (t = 0; t < NUM_THREADS; t++) {
        rc = pthread_create(&threads[t], NULL, count1s, (void *)t);
        if (rc) {
            printf("ERROR; return code from pthread_create() is %d\n", rc);
            exit(-1);
        }
    }

    for (t = 0; t < NUM_THREADS; t++) {
        pthread_join(threads[t], NULL);
    }

    gettimeofday(&end, NULL);

    
    double runtime = (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_usec - start.tv_usec) / 1000000;

    printf("Total count of ones: %d\n", count);
    printf("Runtime: %f seconds\n", runtime);

    
    free(array);
    pthread_mutex_destroy(&count_mutex);

    return 0;
}