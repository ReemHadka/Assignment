#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/time.h>

#define ARRAY_SIZE 10000
#define NUM_THREADS 4 

int *array;
int length = ARRAY_SIZE;
int *thread_counts;
int count=0;
void *count1s(void *thread_id) {
    long tid = (long)thread_id;
    thread_counts[tid] = 0;

    for (int i = tid; i < length; i += NUM_THREADS) {
        if (array[i] == 1) {
            thread_counts[tid]++;
        }
    }

    pthread_exit(NULL);
}

int main() {
    int num_threads = NUM_THREADS; 

    array = (int *)malloc(length * sizeof(int));
    thread_counts = (int *)malloc(num_threads * sizeof(int));

    if (array == NULL || thread_counts == NULL) {
        perror("Error allocating memory for array or thread counts");
        exit(EXIT_FAILURE);
    }

    srand((unsigned int)time(NULL));

    for (int i = 0; i < length; i++) {
        array[i] = rand() % 6;
    }
    for (int j=0; j<length; j++){
        if(array[j]==1){
            count++;
        }
    }
    pthread_t threads[num_threads];
    int rc;
    long t;

    struct timeval start, end;

    gettimeofday(&start, NULL);

    for (t = 0; t < num_threads; t++) {
        rc = pthread_create(&threads[t], NULL, count1s, (void *)t);
        if (rc) {
            fprintf(stderr, "ERROR: return code from pthread_create() is %d\n", rc);
            exit(EXIT_FAILURE);
        }
    }

    for (t = 0; t < num_threads; t++) {
        rc = pthread_join(threads[t], NULL);
        if (rc) {
            fprintf(stderr, "ERROR: return code from pthread_join() is %d\n", rc);
            exit(EXIT_FAILURE);
        }
    }

    gettimeofday(&end, NULL);

    double runtime = (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_usec - start.tv_usec) / 1000000;

    // Combine the thread counts for total count 
    int total_count = 0;
    for (t = 0; t < num_threads; t++) {
        total_count += thread_counts[t];
    }

    printf("Total count of ones: %d\n", total_count);
    printf("Actual count of ones: %d\n", count);
    printf("Runtime: %f seconds\n", runtime);

    free(array);
    free(thread_counts);

    return 0;
}
