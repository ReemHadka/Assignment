#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/time.h>

#define ARRAY_SIZE 10000
#define NUM_THREADS 32
#define CACHE_LINE_SIZE 64 

int *array;
int length = ARRAY_SIZE;
int count = 0;

struct CacheAlignedCounter {
    int private_count;
    char padding[CACHE_LINE_SIZE - sizeof(int)]; 
};

struct CacheAlignedCounter local_counts[NUM_THREADS];

void *count1s(void *thread_id) {
    long tid = (long)thread_id;
    int local_count = 0;

    for (int i = tid; i < length; i += NUM_THREADS) {
        if (array[i] == 1) {
            local_count++;
        }
    }


    local_counts[tid].private_count = local_count;

    pthread_exit(NULL);
}

int main() {
    array = (int *)malloc(length * sizeof(int));
    srand((unsigned int)time(NULL));


    for (int i = 0; i < length; i++) {
        array[i] = rand() % 6;
    }

    
    pthread_t threads[NUM_THREADS];
    int rc;
    long t;

    struct timeval start, end;

    gettimeofday(&start, NULL);


    for (t = 0; t < NUM_THREADS; t++) {
        rc = pthread_create(&threads[t], NULL, count1s, (void *)t);
        if (rc) {
            printf("ERROR; return code from pthread_create() is %d\n", rc);
            exit(-1);
        }
    }

    
    for (t = 0; t < NUM_THREADS; t++) {
        pthread_join(threads[t], NULL);
    }

    for (t = 0; t < NUM_THREADS; t++) {
        count += local_counts[t].private_count;
    }

    gettimeofday(&end, NULL);

    
    double runtime = (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_usec - start.tv_usec) / 1000000;

    printf("Total count of ones: %d\n", count);
    printf("Runtime: %f seconds\n", runtime);

    
    free(array);

    return 0;
}

